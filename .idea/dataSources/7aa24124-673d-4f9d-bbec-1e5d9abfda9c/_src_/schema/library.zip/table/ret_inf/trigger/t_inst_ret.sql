CREATE TRIGGER t_inst_ret
AFTER INSERT ON ret_inf
FOR EACH ROW
  begin
update book_inf  set bookNum=bookNum+1
where bookID=NEW.bookID;
end;
