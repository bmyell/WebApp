CREATE TRIGGER t_inst_bor
AFTER INSERT ON borrow_inf
FOR EACH ROW
  begin
update book_inf  set bookNum=bookNum-1
where bookID=NEW.bookID;
end;
